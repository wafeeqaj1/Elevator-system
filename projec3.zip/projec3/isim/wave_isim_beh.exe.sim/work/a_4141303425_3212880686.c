/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/wafee/Desktop/ECE 3561/projec3/simulator.vhd";
extern char *IEEE_P_1242562249;

char *ieee_p_1242562249_sub_1919437128_1035706684(char *, char *, char *, char *, int );
unsigned char ieee_p_1242562249_sub_2110375371_1035706684(char *, char *, char *, char *, char *);
char *ieee_p_1242562249_sub_2540846514_1035706684(char *, char *, char *, char *, int );
char *ieee_p_1242562249_sub_2547962040_1035706684(char *, char *, char *, char *, int );


static void work_a_4141303425_3212880686_p_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    xsi_set_current_line(50, ng0);

LAB3:    t1 = (t0 + 2472U);
    t2 = *((char **)t1);
    t1 = (t0 + 4296);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 4U);
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t7 = (t0 + 4200);
    *((int *)t7) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_4141303425_3212880686_p_1(char *t0)
{
    char t17[16];
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    unsigned char t10;
    char *t11;
    unsigned char t12;
    unsigned char t13;
    char *t14;
    char *t15;
    char *t16;
    char *t18;
    char *t19;
    int t20;
    unsigned int t21;
    unsigned char t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    unsigned int t27;
    unsigned int t28;

LAB0:    xsi_set_current_line(53, ng0);
    t2 = (t0 + 1632U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 4216);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(55, ng0);
    t4 = (t0 + 1832U);
    t8 = *((char **)t4);
    t9 = *((unsigned char *)t8);
    t10 = (t9 == (unsigned char)2);
    if (t10 != 0)
        goto LAB8;

LAB10:    t2 = (t0 + 1832U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t3 = (t1 == (unsigned char)3);
    if (t3 != 0)
        goto LAB38;

LAB39:
LAB9:    goto LAB3;

LAB5:    t4 = (t0 + 1672U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB8:    xsi_set_current_line(56, ng0);
    t4 = (t0 + 1992U);
    t11 = *((char **)t4);
    t12 = *((unsigned char *)t11);
    t13 = (t12 == (unsigned char)2);
    if (t13 != 0)
        goto LAB11;

LAB13:    xsi_set_current_line(64, ng0);
    t2 = (t0 + 1032U);
    t4 = *((char **)t2);
    t3 = *((unsigned char *)t4);
    t6 = (t3 == (unsigned char)3);
    if (t6 == 1)
        goto LAB22;

LAB23:    t1 = (unsigned char)0;

LAB24:    if (t1 != 0)
        goto LAB19;

LAB21:    t2 = (t0 + 1192U);
    t4 = *((char **)t2);
    t3 = *((unsigned char *)t4);
    t6 = (t3 == (unsigned char)3);
    if (t6 == 1)
        goto LAB29;

LAB30:    t1 = (unsigned char)0;

LAB31:    if (t1 != 0)
        goto LAB27;

LAB28:    t2 = (t0 + 1352U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t3 = (t1 == (unsigned char)3);
    if (t3 != 0)
        goto LAB34;

LAB35:    t2 = (t0 + 1512U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t3 = (t1 == (unsigned char)3);
    if (t3 != 0)
        goto LAB36;

LAB37:
LAB20:
LAB12:    goto LAB9;

LAB11:    xsi_set_current_line(57, ng0);
    t4 = (t0 + 2312U);
    t14 = *((char **)t4);
    t4 = (t0 + 6676U);
    t15 = (t0 + 6729);
    t18 = (t17 + 0U);
    t19 = (t18 + 0U);
    *((int *)t19) = 0;
    t19 = (t18 + 4U);
    *((int *)t19) = 2;
    t19 = (t18 + 8U);
    *((int *)t19) = 1;
    t20 = (2 - 0);
    t21 = (t20 * 1);
    t21 = (t21 + 1);
    t19 = (t18 + 12U);
    *((unsigned int *)t19) = t21;
    t22 = ieee_p_1242562249_sub_2110375371_1035706684(IEEE_P_1242562249, t14, t4, t15, t17);
    if (t22 != 0)
        goto LAB14;

LAB16:    xsi_set_current_line(60, ng0);
    t2 = (t0 + 2312U);
    t4 = *((char **)t2);
    t2 = (t0 + 6676U);
    t5 = ieee_p_1242562249_sub_1919437128_1035706684(IEEE_P_1242562249, t17, t4, t2, 1);
    t8 = (t17 + 12U);
    t21 = *((unsigned int *)t8);
    t27 = (1U * t21);
    t1 = (3U != t27);
    if (t1 == 1)
        goto LAB17;

LAB18:    t11 = (t0 + 4424);
    t14 = (t11 + 56U);
    t15 = *((char **)t14);
    t16 = (t15 + 56U);
    t18 = *((char **)t16);
    memcpy(t18, t5, 3U);
    xsi_driver_first_trans_fast(t11);

LAB15:    goto LAB12;

LAB14:    xsi_set_current_line(58, ng0);
    t19 = (t0 + 4360);
    t23 = (t19 + 56U);
    t24 = *((char **)t23);
    t25 = (t24 + 56U);
    t26 = *((char **)t25);
    *((unsigned char *)t26) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t19);
    goto LAB15;

LAB17:    xsi_size_not_matching(3U, t27, 0);
    goto LAB18;

LAB19:    xsi_set_current_line(65, ng0);
    t8 = (t0 + 4360);
    t11 = (t8 + 56U);
    t14 = *((char **)t11);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t8);
    xsi_set_current_line(66, ng0);
    t2 = (t0 + 6732);
    t5 = (t0 + 4424);
    t8 = (t5 + 56U);
    t11 = *((char **)t8);
    t14 = (t11 + 56U);
    t15 = *((char **)t14);
    memcpy(t15, t2, 3U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(67, ng0);
    t2 = (t0 + 2472U);
    t4 = *((char **)t2);
    t2 = (t0 + 6692U);
    t5 = ieee_p_1242562249_sub_2540846514_1035706684(IEEE_P_1242562249, t17, t4, t2, 1);
    t8 = (t17 + 12U);
    t21 = *((unsigned int *)t8);
    t27 = (1U * t21);
    t1 = (4U != t27);
    if (t1 == 1)
        goto LAB25;

LAB26:    t11 = (t0 + 4488);
    t14 = (t11 + 56U);
    t15 = *((char **)t14);
    t16 = (t15 + 56U);
    t18 = *((char **)t16);
    memcpy(t18, t5, 4U);
    xsi_driver_first_trans_fast(t11);
    goto LAB20;

LAB22:    t2 = (t0 + 2472U);
    t5 = *((char **)t2);
    t20 = (4 - 4);
    t21 = (t20 * -1);
    t27 = (1U * t21);
    t28 = (0 + t27);
    t2 = (t5 + t28);
    t7 = *((unsigned char *)t2);
    t9 = (t7 == (unsigned char)2);
    t1 = t9;
    goto LAB24;

LAB25:    xsi_size_not_matching(4U, t27, 0);
    goto LAB26;

LAB27:    xsi_set_current_line(70, ng0);
    t8 = (t0 + 4360);
    t11 = (t8 + 56U);
    t14 = *((char **)t11);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t8);
    xsi_set_current_line(71, ng0);
    t2 = (t0 + 6735);
    t5 = (t0 + 4424);
    t8 = (t5 + 56U);
    t11 = *((char **)t8);
    t14 = (t11 + 56U);
    t15 = *((char **)t14);
    memcpy(t15, t2, 3U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(72, ng0);
    t2 = (t0 + 2472U);
    t4 = *((char **)t2);
    t2 = (t0 + 6692U);
    t5 = ieee_p_1242562249_sub_2547962040_1035706684(IEEE_P_1242562249, t17, t4, t2, 1);
    t8 = (t17 + 12U);
    t21 = *((unsigned int *)t8);
    t27 = (1U * t21);
    t1 = (4U != t27);
    if (t1 == 1)
        goto LAB32;

LAB33:    t11 = (t0 + 4488);
    t14 = (t11 + 56U);
    t15 = *((char **)t14);
    t16 = (t15 + 56U);
    t18 = *((char **)t16);
    memcpy(t18, t5, 4U);
    xsi_driver_first_trans_fast(t11);
    goto LAB20;

LAB29:    t2 = (t0 + 2472U);
    t5 = *((char **)t2);
    t20 = (1 - 4);
    t21 = (t20 * -1);
    t27 = (1U * t21);
    t28 = (0 + t27);
    t2 = (t5 + t28);
    t7 = *((unsigned char *)t2);
    t9 = (t7 == (unsigned char)2);
    t1 = t9;
    goto LAB31;

LAB32:    xsi_size_not_matching(4U, t27, 0);
    goto LAB33;

LAB34:    xsi_set_current_line(75, ng0);
    t2 = (t0 + 4360);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t11 = (t8 + 56U);
    t14 = *((char **)t11);
    *((unsigned char *)t14) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t2);
    xsi_set_current_line(76, ng0);
    t2 = (t0 + 6738);
    t5 = (t0 + 4424);
    t8 = (t5 + 56U);
    t11 = *((char **)t8);
    t14 = (t11 + 56U);
    t15 = *((char **)t14);
    memcpy(t15, t2, 3U);
    xsi_driver_first_trans_fast(t5);
    goto LAB20;

LAB36:    xsi_set_current_line(79, ng0);
    t2 = (t0 + 4360);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t11 = (t8 + 56U);
    t14 = *((char **)t11);
    *((unsigned char *)t14) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t2);
    xsi_set_current_line(80, ng0);
    t2 = (t0 + 6741);
    t5 = (t0 + 4424);
    t8 = (t5 + 56U);
    t11 = *((char **)t8);
    t14 = (t11 + 56U);
    t15 = *((char **)t14);
    memcpy(t15, t2, 3U);
    xsi_driver_first_trans_fast(t5);
    goto LAB20;

LAB38:    xsi_set_current_line(85, ng0);
    t2 = (t0 + 6744);
    t8 = (t0 + 4488);
    t11 = (t8 + 56U);
    t14 = *((char **)t11);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    memcpy(t16, t2, 4U);
    xsi_driver_first_trans_fast(t8);
    xsi_set_current_line(86, ng0);
    t2 = (t0 + 4360);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t11 = *((char **)t8);
    *((unsigned char *)t11) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t2);
    goto LAB9;

}


extern void work_a_4141303425_3212880686_init()
{
	static char *pe[] = {(void *)work_a_4141303425_3212880686_p_0,(void *)work_a_4141303425_3212880686_p_1};
	xsi_register_didat("work_a_4141303425_3212880686", "isim/wave_isim_beh.exe.sim/work/a_4141303425_3212880686.didat");
	xsi_register_executes(pe);
}
